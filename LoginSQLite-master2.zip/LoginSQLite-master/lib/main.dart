import 'package:flutter/material.dart';
import 'package:login_sqlite/src/app.dart';

void main() => runApp(MyApp());